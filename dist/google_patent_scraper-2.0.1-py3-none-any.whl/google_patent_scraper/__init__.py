from .main import Scraper, Patent

name='google_patents_scraper'
