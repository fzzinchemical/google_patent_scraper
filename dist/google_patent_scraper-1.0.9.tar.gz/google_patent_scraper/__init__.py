from .main import scraper_class

name='google_patents_scraper'
