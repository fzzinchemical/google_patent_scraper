# define Python user-defined exceptions
PATENT_CLASS_ERROR = "Raised when the input value is too small"
NO_PATENTS_ERROR = """no patents to scrape specified in 'patent' variable:
                        add patent using class.add_patents([<PATENTNUMBER>])"""
