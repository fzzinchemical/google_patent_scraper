from .main import Scraper

name='google_patents_scraper'
